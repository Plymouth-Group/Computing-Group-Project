# Group Project - IDE

> Technical Report writing workload according to the table of contents

****

**Shared DOCX Link:** [https://1drv.ms/w/s!AoHHjvWR8lh7fpJqE0hOdusv5eU?e=wlO6m1](https://1drv.ms/w/s!AoHHjvWR8lh7fpJqE0hOdusv5eU?e=wlO6m1)

**Submission Date:** 02 January 2022

**Need to finish this Document before:** 31 December 2021

****

> Note:
>
> 1. Don't copy content from internet
> 2. Think, Do Research, Analyze and write
> 3. No need of formating, just wite
> 4. For diagrams, use **Draw IO**, because we can upload `.drawio` files to the GitHub
> 5. No need of **JetBrains YouTrack**, but sir said to use version controling and project management tool like Jira, Clickup or something. So you have to decide what tool we used!

****

## Abstract

**Lasan**

## Table of Contents

**Lasan**

## List of Figures

*Nah..*

## Table of Figures

*Nah..*

## Chapter 01

* Introduction - **Piyumi**
* Problem Definition - **Lasan**
* Project Objectives - **Pasindu**
* Scope of Project - **Chanaka**
* Chapter Summary - **Chanaka**

## Chapter 02

* Requirement Gathering Techniques - **Navodya**
* Existing System - **Navodya**
* Diagrams
	* Use Case Diagram - **Piyumi**
	* ER Diagram - **Lasan**
	* Class Diagram - **Lasan**
* High-level Architecture Diagram - **Lasan**
* Chapter Summary - **Navodya**

## Chapter 03

* Functional Requirement - **Pasindu**
* Non – Functional Requirement - **Chanaka**
* Hardware Requirement - **Chanaka**
* Chapter Summary - **Piyumi**

## Chapter 04

* Development Methodology - **Piyumi**
* Programming Languages and Tools - **Piyumi**
* Third Party Libraries - **Pasindu**
* Hardware tools - **Navodya**
* Chapter Summary - **Pasindu**

## References

**Lasan**, **Chanaka**, **Pasindu**, **Piyumi**, **Navodya**

## Team Plan & Responsibility Matrix

**Chanaka**, **Pasindu**, **Navodya**

****

Total

```
Lasan    -> 07
Chanaka  -> 06
Pasindu  -> 06
Piyumi   -> 06
Navodya  -> 06
```

****

Bye Bye gyz