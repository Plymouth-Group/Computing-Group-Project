# Abstract
The Integrated Development Environment (IDE) is a software development environment that gives programmers tools like code completion and correcting, source code editing and management, automated testing, and more. The transition of software from the desktop to the Web is happening at a breakneck pace.  When programmers create websites, members of the web development team must collaborate from multiple locations. Collaborating and coordinating at the same time is incredibly difficult in such scenarios. Website developers and software engineers use social media software engineering technologies like GitHub and Source Forge to get past these challenges. The Integrated development environment is well-suited to real-time editing (IDE). Our project entails not only UI/UX design of the site for all team members at the same time, but also UI development using HTML, CSS, SASS, LESS, and JS web development languages as a solution to the issues that developers experience while building web sites as a group. By offering space, it simplifies things. The "Codinoc IDE," which is being developed as an open-source cloud software, includes syntax highlighting, code complement, brace matching, indentation, team chat, and other capabilities. This IDE can be used on any operating system, including Windows, Linux, Android, Mac, and iOS. We'll give you a fast overview of the Codinoc IDE development process so far, including the tools and techniques we'll need through this document.
Keywords: Integrated development environment, Open-Source, Cloud
# Chapter 01

## Introduction
In today's world, software development is a vital activity. Previously, programmers would enter codes into text files, which would subsequently be converted into software programs using command line tools such as compilers and similar tools. The term "cloud IDE" refers to a web-based integrated development environment. Codinoc is a web-based designer's cloud-based integrated development environment. What is an IDE, exactly? To produce computer software or mobile apps, most programmers use an Integrated Development Environment (IDE). An integrated development environment (IDE) is a software development environment that allows you to write, run, and debug software all in one location. In this century, everything is connected to the internet, and no one can function without it. 
Websites and pages make up most of the Internet. There are two sorts of websites: static and dynamic. Static sites just have a front end, whereas dynamic sites have both a front end and a back end. So, how do you go about making websites and pages? We'll need to employ specialized software for that. Programming languages come first, followed by editors. JS, PHP, Ruby, HTML (Hypertext Markup Language), CSS, and other languages are used in web design and development. Anyone can use any text editor, code editor, or integrated development environment to create a web application (IDE). However, code editors like Sublime Text, Visual Studio Code, Brackets, JetBrains WebStorm, JetBrains PHP Storm, and others offer a variety of useful and powerful features like Syntax Highlighting, Code Complement, Indentation, Brace Matching, and so on. On the other hand, building a website might be a difficult undertaking. The development process will be less problematic if you build a website with a team. You'll also need to use third-party tools like GitHub and GitLab. As a result of this project, we are presenting the "Codonic IDE" to assist you in completing your group projects with ease. Codonic is a cloud-based IDE that allows any team to collaborate remotely on any operating system, including Windows, Linux, Mac, iOS, and Android. Only for producing cloud-hosted web-based apps like our Codinoc IDE, web pages / sites, mobile applications, and desktop applications. Finally, you can successfully merge UI development processes into a single application using our cloud-based IDE. 
In this article, we will present a brief overview of the Codinoc IDE development process thus far, as well as the tools and techniques necessary. In comparison to most other web IDEs, the Codinoc IDE takes a fresh approach to web design, development, and collaboration.


## Definition of the Problem
When a software is developed by a group of individuals rather than by a single person, it can be completed rapidly. This is because the relevant software's development process can be shared. In a company, this is a simple task. This is because in a normal software development firm, all the computers are connected, making it simple to complete. But what if this is done by a regular team, not a company? There are no direct connections between the computers of the participants. You must share the project linked to the software developed by the team in this section.
Look at this example. Assume you're working on a mobile app with a group of people. Here are the fundamentals: The UI Design Process and the App Development Process are two separate processes. You can utilize online software like Figma and Lunacy to help you with the UI design process. However, consider the app development process. What is the procedure? The project should be divided between the team. For this difficulty, software like as Visual Studio provides Team assistance. Is it, however, usable by everyone? Let's pretend I'm a Linux user, a Mac user, and a Windows user. Simply put, this is our problem.


## Project Objectives
The main objective of our project is to connect a team of web designers in one place and allow web-based applications to be designed together. We provide group chat box features to make easier developers tasks.

## Scope of the Project
The cloud IDE which we build is easy to use and will support languages including HTML, CSS, Java Script, SASS, SCSS, and LESS. Project Templates, Team Collaboration and Chat, Built-In Live Preview, Built-In Storage per Team, and a Full Featured Text Editor are all included. The IDE incorporates project files that you work on, as well as full source file version control and the ability to save source files automatically. The IDE incorporates project files that you work on, as well as full source file version control and the ability to save source files automatically. Our project's major goal is to bring together a group of web designers in one place and allow them to collaborate on web-based applications.

## Summary
Codinoc is a cloud-based Integrated Development Environment. Anyone can use any text editor, code editor, or integrated development environment to create a web application. When you build a website as part of a team, you'll have fewer issues during the development process. So, for producing cloud-hosted web-based applications like our Codinoc IDE, web pages / sites, mobile applications, and desktop applications. As a result, you may successfully merge UI development processes into a single application using our cloud-based IDE. This will provide you a quick overview of the Codinoc IDE development process, including the tools and techniques you'll need. The Codinoc IDE takes a different approach to online design development and teamwork than most existing web IDEs.

# Chapter 02

## Facts gathering techniques

**Online Research:**

We did online research to gather facts about our project. First, we searched for other tools similar to our project. Then we found some tools such as Code Pen, Ideone, Private Bin, Write As, etc. After that, we looked into that tools deeply. Then we list down the special features of that tools.

**Conduct a brainstorming session:**

We first discussed each other's ideas on what an IDE is. We then proceeded to gather information
about the IDE from books on the Internet.

**Study analogous systems:**

Here we have studied the existing text editors such as sublime text, Vim, notepad, ace editor etc.
under several sections. We have primarily explored the available features, the technology used, the
RAM usage, the language in which they are accessed, and the language used to create them.

**Examine suggestions and problem reports:**

What we did with this was identify the vulnerabilities in the current hot editors currently in use. We
then prepared a report for each of them and then made suggestions to them.

**Talk with supporters:**

Prior to creating Codinoc, we consulted with people with experience in the field.

**Attend Conduct collaborative workshops:**

Join workshops organized by the university or other organization affiliated with this department to
gain knowledge about this. They also exchanged pdfs, videos, etc. and books written on the subject
and shared knowledge.

## Current System

The current system is an online Integrated Development Environment for testing and building Web-based applications using HTML, CSS, and Java Scripts.

## Overall use case diagram for the current system

> Done

## Drawbacks of the current system

Our project is a completely web-based application. In the modern era, all websites are mobile responsive because 52% of the internet traffic came from mobile devices and 4% of the internet traffic came from tablet devices. But we're only developing this application for desktop screen sizes because mobile or tablet screen sizes can't handle elements of our application such as Editor Window, Models, etc. Another drawback of our application is, our application does not support multi-person single file editing.

## Summary

In this chapter, we discussed how we gathered information about our project and similar projects and how we analyzed those features. There are some shortcomings in our project and we discussed the two main drawbacks of our project.

# Chapter 03

## Functional Requirements

- Shall be able to create new Projects
- Shall be able to works with multiple projects
- Multi Member Login per Server
- Project Templates
- Team Collaboration and Chat
- Built-In Live Preview
- Built-In Storage per Team
- Source File Auto Save
- Full Featured Text Editor

## Non Functional Requirements

- Desktop screen size optimized user interface
- Dark and Light themes for Application
- Advanced password security with Hash Algorithms
- Maximum 10 members per Server / Team

## Performance Requirements

- Shall be able to run on any modern web browser

## Security Requirements

- The system should manage and maintain user accounts
- Server data can only be accessed by the administrator of server or team member by login with user name or email address and password

## Hardware Requirements

- Any typy of computer that runs desktop Operating Systems such as Windows, Linux, Unix or Machintosh
- Keyboard
- Mouse

## Networking Requirements

> Nah!!

## Safety Requirements

> Nah!!

## Summary

# Chapter 04

## Economic Feasibility

## Operational Feasibility

## Technical Feasibility

## Organizational Feasibility

## Outline Budget

## Summary

# Chapter 05

## Class Diagram of the System

## Database Class Diagram

Class Diagram of the Databases
In this project, we use multi tenant database concept and we use two databases for our application. The 1st one is Site Database and the second one is Server Database. Site database contains all the data about our application and server database contains all the data about server per account.

### Class Diagram for Site Database

> Done

### Class Diagram for Server / Account Database

> Done

## ER Diagram of the System

> From previous Report

## HLA Diagram

The High-level architecture diagram depicts how the Codinoc IDE's main design of the system development is carried out. The overall system is depicted in the high-level architectural diagram. A high-level architecture analysis also allows for the identification of the major components of IDEs and its interfaces.

> From previous Report

## Network Diagram

## Site Map Diagram

> Done

## Summary

# Chapter 06

## Development Methodology

Language sites such as HTML, CSS, and JS require three simple steps to write software, mainly for
web design:

- Edit the code
- Compile the code
- Run the code

You will need a text editor and a compiler for this. For this, basically give a feature bonus in the cloud
IDE for work as a team.

As indicated IDE there are distinct functions: for design modification: IDE design and IDE
development. This can be accomplished using the Software Development Lifecycle (SDLC).
The Software Development Lifecycle (SDLC) is a well-structured phase stream that enables you to
produce advanced software rapidly and easily for a range of purposes.

SDLC Methodology mainly focuses at the following software development phases:

- Analyze requirements
- Planning
- Design Software Model
- Software development
- Testing
- Maintenance

The waterfall model, the spiral model, the Agile model, and the V-shaped model are examples of
software development life cycles (SDLC). The Agile model is the one that is most commonly utilized
for IDE development.

Of these, the Agile model was primarily used for Codinoc IDE development as it is an agile software
development process that, when properly implemented, allows the team to drastically improve the
quality of the software in each release. Also, team members are able to adapt quickly. Furthermore,
the Agile model is more appropriate because the Codinoc IDE project's UI DEVELOPMENT and
DATABASE DEVELOPMENT processes occur at the same time.

## Programming Language and Tools

- **GO Language**: We choose go language as our application's backend programming language because go language is much faster than PHP, ASP.NET or any other programming language we learned in the university. GO language produce binary executable and GO is a functional programming language. 
- **Java Script**: Java Script is the main language of internet and it support all web browsers for client side scripting
- **SCSS**: We use SCSS instead of CSS because SCSS is very easy when writing large CSS code base.
- **HTML**: We need HTML for desing front end of our application.
- **PostgreSQL Database**: PostgreSQL is faster than MySQL or MariaDB according to statics and Schema concept of PostgreSQL is very useful when creating multi tenant database appplication

## Third Party Components and Libraries

### TreeJS

<https://www.cssscript.com/folder-tree-treejs/>

TreeJS is a pure javascript library for represent Tree like data structure in web application. TreeJS support highly customization and because of that we decided to use it as our main directory explorer in editor.

### JQuery Tabs

<https://jqueryui.com/tabs/>

Any IDE or code editor need tab support for work with multiple files in same time. JQuery Tab is a highly customizable library for create advanced tabs in web application.

### ACE Editor

<https://github.com/ajaxorg/ace>

It is too hard to create a code editor from scratch and it taks too much time and too much knowledge. Because of that we decided to choose ACE editor as our application's main editor because ACE editor is highly customizable and it supports 100 of languages including HTML, CSS, SCSS and JS.

### Lucide Icons

<https://icon-sets.iconify.design/lucide/>

In any application, we need to use icons for visualy represent some items tasks ect. So we decided to use Lucide Icons framework. It is a opensource licensed framework and match perfect with our application.

### Admin LTE

<https://adminlte.io/>

We decided to use custom template for our application's administrator section. ADMIN LTE template is a bootstrap framework based template and it has hundreds of elements that perfectly match with our application administrator section.

### GO Language Packages

#### Gorilla Handlers

<https://github.com/gorilla/handlers>

By sending a compressed response we save bandwidth and download time eventually rendering the page faster. Result of that we can save server resources. So we decided to use Gorilla Handlers custom package instead of default GO packages.

#### Gorilla Mux

<https://github.com/gorilla/mux>

We need to define more than one URL's in our application such as:

- xxx.com/
- xxx.com/about
- xxx.com/contact
- xxx.com/sign_in
- xxx.com/sign_up ...

The default package of GO language is slower than Gorilla Mux package and we decided to implement domain rounting system using Gorilla Mux package.

## Algorithms

### Hash Algorithm

<https://www.password-hashing.net/#argon2>

We use `Argon 2` hash algorithm for encrypt password given by uses when creating accounts in our application. There are several reasons to choose this algorithm as our main password hashing algorithm.

- A time cost, which defines the execution time
- A memory cost, which defines the memory usage
- A parallelism degree, which defines the number of threads

## Hardware Tools

We didn't use any hardware components.

## Summary

In this chapter we discucced about main parts of out project.

# Chapter 07

## Discussion

## References

- Mbp.ms.gov. 2022. [online] Available at:
<https://www.mbp.ms.gov/Documents/PMP%20NextGen%20Software.pdf >[Accessed 1
January 2022].
- Sites.nationalacademies.org. 2022. [online] Available at:
<https://sites.nationalacademies.org/cs/groups/pgasite/documents/webpage/pga_17912
9.pdf> [Accessed 1 January 2022].
- Ijser.org. 2022. [online] Available at: <https://www.ijser.org/researchpaper/Different-
Requirements-Gathering-Techniques-and-Issues.pdf> [Accessed 1 January 2022].
- AgiraTechnologies. 2021. 7 Reasons To Choose Golang for Development | Hire Golang
Developers. [online] Available at::https://www.agiratech.com/7-reasons-why-golang-is-
the-best-programming-language-for-developer [Accessed 31 December 2021].
- 2022. [online] Available at: https://tekeye.uk/programming/how-to-create-an-ide
[Accessed 1 January 2022].

## Team plan responsibilities